public class User 
{
    private int uid;
    private String username;
    private String userpwd;
    private String userAddr;
    public User(int id, String uname, String pwd, String addr)
    {
        uid=id;
        username=uname;
        userpwd=pwd;
        userAddr=addr;
    }     
}