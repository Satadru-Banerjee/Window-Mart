import java.sql.JDBCType;
public class DBConnector {
    
}