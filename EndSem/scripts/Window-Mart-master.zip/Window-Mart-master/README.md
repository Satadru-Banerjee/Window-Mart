# Window-Mart
Simple e-commerce web application with HTML, CSS, JS frontend, Java Servlet backend and MySQL DB
